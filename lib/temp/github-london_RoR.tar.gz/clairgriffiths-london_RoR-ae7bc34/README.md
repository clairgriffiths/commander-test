# london_RoR
List of companies in London that use Ruby on Rails (for potential jobs)

List is stored in the CSV file.