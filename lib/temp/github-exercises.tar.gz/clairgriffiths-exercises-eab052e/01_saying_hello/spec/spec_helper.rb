
require_relative '../hello_spec'

 
require 'yaml