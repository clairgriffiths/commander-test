Planner::Application.config.twitter = ENV['HQ_TWITTER_HANDLE']
Planner::Application.config.twitter_id = ENV['HQ_TWITTER_ID']
