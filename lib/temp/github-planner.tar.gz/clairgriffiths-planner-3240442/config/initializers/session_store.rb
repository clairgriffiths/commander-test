# Be sure to restart your server when you modify this file.

Planner::Application.config.session_store :cookie_store, key: '_planner_session',
                                                         expire_after: 24.hours
