require 'omniauth'

OmniAuth.config.test_mode = true
