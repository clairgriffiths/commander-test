require 'capybara/poltergeist'
Capybara.javascript_driver = :poltergeist
