Fabricator(:sponsor_session) do
end
