Fabricator(:subscription) do
  member
  group
end
