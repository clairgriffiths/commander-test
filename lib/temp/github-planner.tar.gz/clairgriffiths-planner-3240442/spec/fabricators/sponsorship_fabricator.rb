Fabricator(:sponsorship) do
end
