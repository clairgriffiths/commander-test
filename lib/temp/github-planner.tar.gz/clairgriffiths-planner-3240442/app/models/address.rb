class Address < ActiveRecord::Base
  belongs_to :sponsor

end
