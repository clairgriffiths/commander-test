class Testimonial < ActiveRecord::Base
  belongs_to :member
end
