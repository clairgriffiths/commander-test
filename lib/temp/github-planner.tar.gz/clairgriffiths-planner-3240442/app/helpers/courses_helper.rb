module CoursesHelper

  def twitter_url_for username
    "http://twitter.com/#{username}"
  end
end
