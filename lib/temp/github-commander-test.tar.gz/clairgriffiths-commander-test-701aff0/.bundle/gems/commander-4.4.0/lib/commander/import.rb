require 'commander'

include Commander::Methods

at_exit { run! }
