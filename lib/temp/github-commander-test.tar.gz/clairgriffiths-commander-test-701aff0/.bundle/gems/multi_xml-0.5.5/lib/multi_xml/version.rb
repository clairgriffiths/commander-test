module MultiXml
  VERSION = "0.5.5" unless defined?(MultiXML::VERSION)
end
