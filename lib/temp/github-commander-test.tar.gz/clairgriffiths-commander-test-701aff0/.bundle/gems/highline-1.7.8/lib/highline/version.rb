class HighLine
  # The version of the installed library.
  VERSION = "1.7.8".freeze
end
