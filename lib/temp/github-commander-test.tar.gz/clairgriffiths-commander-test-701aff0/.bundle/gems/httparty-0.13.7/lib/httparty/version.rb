module HTTParty
  VERSION = "0.13.7"
end
