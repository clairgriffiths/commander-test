Within the bin folder run `./backup github`
