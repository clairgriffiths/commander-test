This is the source code for <http://tutorials.codebar.io>

## Getting started

This is a [GitHub Pages](https://pages.github.com/) repo, so you can render the pages with [Jekyll](http://jekyllrb.com/):

1. `bundle install`, which will install Jekyll
2. `bundle exec jekyll serve`
3. go to http://127.0.0.1:4000

## Getting in Touch

You can go to [the Slack channel here](https://codebar.slack.com/messages/general/). Use it to get in touch and chat to other codebar students/coaches, or if you need help.

If you are not on Slack use [this link](http://codebar-slack.herokuapp.com/) to get an invite.

## Contributing

We encourage you to contribute with your suggestions and corrections. Head to our [issues page](https://github.com/codebar/tutorials/issues) and open a new issue or help on the existing ones.

## License

codebar Tutorials are released under the [Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)](http://creativecommons.org/licenses/by-nc-sa/4.0/).
