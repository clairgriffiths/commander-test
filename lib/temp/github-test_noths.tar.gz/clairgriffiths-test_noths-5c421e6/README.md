A test for NOTHS
