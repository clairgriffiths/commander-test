require 'test_helper'

class TheatreTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
