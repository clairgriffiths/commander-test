require 'test_helper'

class VisitorsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
