require 'test_helper'

class TheatresControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
