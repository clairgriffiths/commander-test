class PaperclipImage < ActiveRecord::Base
  
  
  
end
