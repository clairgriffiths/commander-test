class StaticPagesController < ApplicationController
  def welcome
  end
end
