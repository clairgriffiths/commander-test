class ShoppingListItem < ActiveRecord::Base
end
