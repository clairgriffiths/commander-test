#HighVoltage.configure do |config|
# config.home_page = 'welcome'
#end

HighVoltage.configure do |config|
  config.routes = false
end