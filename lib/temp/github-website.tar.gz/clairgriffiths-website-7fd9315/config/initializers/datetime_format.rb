Date::DATE_FORMATS[:default] = "%e %b %Y"  # 3 Nov 2013
