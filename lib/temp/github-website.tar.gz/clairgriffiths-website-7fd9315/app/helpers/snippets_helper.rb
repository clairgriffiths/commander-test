module SnippetsHelper
end
