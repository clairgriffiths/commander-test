require 'spec_helper'

describe Board do
  describe ".show_grid" do
    it "draws the current grid to the console" do
    end
  end
end 